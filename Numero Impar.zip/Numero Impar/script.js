let Valor = document.querySelector("#Valor");
let btImpar = document.querySelector("#btImpar");
let Resultado = document.querySelector("#Resultado");

function Impar() {
    let num1 = Number(Valor.value);
    
    if (num1 % 2 !== 0) {
        Resultado.textContent = "É Ímpar";
    } else {
        Resultado.textContent = "Não é Ímpar";
    }
}

btImpar.onclick = function() {
    Impar();
}